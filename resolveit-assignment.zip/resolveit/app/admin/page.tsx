'use client';

import { useEffect, useState } from 'react';

type Case = {
  id: number;
  caseType: string;
  description: string;
  opposingName: string;
  opposingContact: string;
  opposingAddress: string;
  status: string;
  evidence: string;
  createdAt: string;
};

const statuses = ['Pending Review', 'In Progress', 'Resolved', 'Unresolved'];
const caseTypes = ['Family', 'Business', 'Criminal'];

export default function AdminDashboard() {
  const [cases, setCases] = useState<Case[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');

  useEffect(() => {
    const fetchCases = async () => {
      const res = await fetch('/api/admin/cases');
      const data = await res.json();
      setCases(data);
      setLoading(false);
    };

    fetchCases();
  }, []);

  const updateStatus = async (id: number, newStatus: string) => {
    const res = await fetch(`/api/admin/cases/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus }),
    });
    const data = await res.json();
    if (data.success) {
      setCases((prev) =>
        prev.map((c) => (c.id === id ? { ...c, status: newStatus } : c))
      );
    }
  };

  const filteredCases = cases.filter((c) => {
    return (
      (statusFilter ? c.status === statusFilter : true) &&
      (typeFilter ? c.caseType === typeFilter : true)
    );
  });

  const countByStatus = (status: string) =>
    cases.filter((c) => c.status === status).length;

  if (loading) return <p className="text-center mt-10">Loading...</p>;

  return (
    <div className="max-w-6xl mx-auto mt-10 p-6">
      <h1 className="text-2xl font-bold mb-6">📋 Admin Case Dashboard</h1>

      {/* Counters */}
      <div className="flex flex-wrap gap-4 mb-4">
        {statuses.map((status) => (
          <div
            key={status}
            className="bg-gray-100 p-3 rounded shadow text-sm min-w-[150px]"
          >
            <p className="font-medium">{status}</p>
            <p className="text-xl font-bold text-blue-600">
              {countByStatus(status)}
            </p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex gap-4 mb-6">
        <select
          className="p-2 border rounded"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="">All Statuses</option>
          {statuses.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>

        <select
          className="p-2 border rounded"
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
        >
          <option value="">All Case Types</option>
          {caseTypes.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </div>

      {/* Case List */}
      {filteredCases.length === 0 ? (
        <p>No cases found for selected filters.</p>
      ) : (
        filteredCases.map((c) => (
          <div key={c.id} className="border p-4 mb-4 rounded shadow">
            <div className="flex justify-between items-start">
              <div>
                <p><strong>Type:</strong> {c.caseType}</p>
                <p><strong>Status:</strong> {c.status}</p>
                <p><strong>Description:</strong> {c.description}</p>
                <p><strong>Opposing:</strong> {c.opposingName}</p>
                {c.evidence && (
                  <a href={c.evidence} target="_blank" className="text-blue-600 underline mt-2 block">
                    View Evidence
                  </a>
                )}
              </div>
              <div className="space-y-2 text-right">
                {statuses.map((s) => (
                  <button
                    key={s}
                    onClick={() => updateStatus(c.id, s)}
                    className={`px-2 py-1 rounded text-white text-xs ${
                      s === 'Resolved' ? 'bg-green-600' :
                      s === 'In Progress' ? 'bg-yellow-500' :
                      s === 'Unresolved' ? 'bg-red-600' :
                      'bg-gray-500'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
