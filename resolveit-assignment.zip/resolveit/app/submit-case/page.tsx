'use client';

import { useState } from 'react';

export default function SubmitCasePage() {
  const [form, setForm] = useState({
    caseType: '',
    description: '',
    opposingName: '',
    opposingContact: '',
    opposingAddress: '',
    userId: '1', // Later: replace with logged-in user
    evidence: null as File | null,
  });

  const [message, setMessage] = useState('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setForm({ ...form, evidence: e.target.files[0] });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage('');

    let fileUrl = '';
    if (form.evidence) {
      const uploadData = new FormData();
      uploadData.append('file', form.evidence);

      const uploadRes = await fetch('/api/upload', {
        method: 'POST',
        body: uploadData,
      });

      const uploadJson = await uploadRes.json();
      fileUrl = uploadJson.fileUrl;
    }

    const res = await fetch('/api/case', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, evidence: fileUrl }),
    });

    const data = await res.json();
    setMessage(data.message);
  };

  return (
    <div className="max-w-xl mx-auto mt-10 p-6 border rounded shadow">
      <h1 className="text-xl font-bold mb-4">Register a Case</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <select
          className="w-full p-2 border"
          value={form.caseType}
          onChange={(e) => setForm({ ...form, caseType: e.target.value })}
        >
          <option value="">Select Case Type</option>
          <option value="Family">Family</option>
          <option value="Business">Business</option>
          <option value="Criminal">Criminal</option>
        </select>

        <textarea
          placeholder="Issue Description"
          className="w-full p-2 border"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
        />

        <input
          type="text"
          placeholder="Opposing Party Name"
          className="w-full p-2 border"
          value={form.opposingName}
          onChange={(e) => setForm({ ...form, opposingName: e.target.value })}
        />

        <input
          type="text"
          placeholder="Opposing Party Contact"
          className="w-full p-2 border"
          value={form.opposingContact}
          onChange={(e) => setForm({ ...form, opposingContact: e.target.value })}
        />

        <input
          type="text"
          placeholder="Opposing Party Address"
          className="w-full p-2 border"
          value={form.opposingAddress}
          onChange={(e) => setForm({ ...form, opposingAddress: e.target.value })}
        />

        {/* ✅ File Upload */}
       <input
  type="file"
  accept="image/*,video/*,audio/*,application/pdf"
  onChange={handleFileChange}
  className="w-full p-2 border"
/>


        <button className="bg-blue-600 text-white px-4 py-2" type="submit">
          Submit Case
        </button>
      </form>
      {message && <p className="mt-4 text-green-600">{message}</p>}
    </div>
  );
}
