import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const {
      caseType,
      description,
      opposingName,
      opposingContact,
      opposingAddress,
      userId,
      evidence
    } = body;

    if (!caseType || !description || !opposingName || !userId) {
      return NextResponse.json({ message: 'Missing required fields' }, { status: 400 });
    }

    const parsedUserId = parseInt(userId);
    if (isNaN(parsedUserId)) {
      return NextResponse.json({ message: 'Invalid user ID' }, { status: 400 });
    }

    const newCase = await prisma.case.create({
      data: {
        caseType,
        description,
        opposingName,
        opposingContact: opposingContact || '',
        opposingAddress: opposingAddress || '',
        userId: parsedUserId,
        evidence: evidence || '',
      },
    });

    return NextResponse.json(
      { message: 'Case registered successfully', case: newCase },
      { status: 201 }
    );
  } catch (error: any) {
    console.error('🔥 Case creation error:', error.message);
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    );
  }
}
