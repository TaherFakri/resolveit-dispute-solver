import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const { status } = await req.json();

  const updated = await prisma.case.update({
    where: { id: parseInt(params.id) },
    data: { status },
  });

  return NextResponse.json({ success: true, case: updated });
}
