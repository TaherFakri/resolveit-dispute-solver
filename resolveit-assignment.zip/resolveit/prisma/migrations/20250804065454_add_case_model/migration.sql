-- CreateTable
CREATE TABLE "Case" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "caseType" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "opposingName" TEXT NOT NULL,
    "opposingContact" TEXT NOT NULL,
    "opposingAddress" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'Pending Review',
    "userId" INTEGER NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Case_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
