-- AlterTable
ALTER TABLE "Case" ADD COLUMN "evidence" TEXT;
